import PageNav from '../components/PageNav';
import { useEffect, useState } from 'react';
import axios from 'axios';
import styles from './Compare.module.css';

function Compare() {
  const [users, setUsers] = useState([]);
  const [suburb, setSuburb] = useState([]);
  const [avg, setAvg] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res1 = await axios.get('http://localhost:5000/process');
      const res2 = await axios.get('http://localhost:5000/generate_user');

      const suburbs = Array.from(new Set(res1.data.flatMap(item => item.suburb.split(';'))));

      setSuburb(suburbs.map(name => {
        const oldArea = suburb.find(s => s.name === name);
        return { name, checked: oldArea ? oldArea.checked : false };
      }));

      let usersData = res2.data;
      const selectedSuburbs = suburb.filter(s => s.checked).map(s => s.name);

      if (selectedSuburbs.length > 0) {
        usersData = usersData.filter(user => selectedSuburbs.includes(user.suburb));
      }

      // Sort users by all_overhead
      usersData.sort((a, b) => a.all_overhead - b.all_overhead);
      
      setUsers(usersData);
      setAvg(handlerAvg(usersData));
    } catch (error) {
      setError(error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  function handlerAvg(users) {
    return users.reduce((pre, cur) => pre + cur.all_overhead, 0) / users.length;
  }

  function handleAreaChange(index) {
    const newSuburb = [...suburb];
    newSuburb[index].checked = !newSuburb[index].checked;
    setSuburb(newSuburb);
    fetchData();
  }

  return (
    <div>
      <PageNav/>
      <div className={styles.container}>
        <div className={styles.left}>
          <ul>
            <li onClick={() => setSuburb(suburb.map(s => ({ ...s, checked: false })))}>All Area</li>
            {suburb.map((area, index) => (
              <li key={area.name}>
                <input
                  type="checkbox"
                  checked={area.checked}
                  onChange={() => handleAreaChange(index)}
                />
                {area.name}
              </li>
            ))}
          </ul>
        </div>
        <div className={styles.right}>
          {loading ? (
            <p>Loading...</p>
          ) : error ? (
            <p>Error: {error.message}</p>
          ) : (
            <>
              <div className={styles.top}>
                Average: ${avg}
              </div>
              <div className={styles.buttom}>
                {users.length > 0 ? (
                  <table className={styles.users}>
                    <thead>
                      <tr>
                        <th>Rank</th>
                        <th>username</th>
                        <th>gas_emi_per_day</th>
                        <th>ele_emi_per_day</th>
                        <th>all_overhead</th>
                        <th>suburb</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((user, index) => (
                        <tr key={index}>
                          <td>{index + 1}</td>
                          <td>{user.name}</td>
                          <td>{user.gas_emi_per_day}</td>
                          <td>{user.ele_emi_per_day}</td>
                          <td>{user.all_overhead}</td>
                          <td>{user.suburb}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <p>No data</p>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default Compare;
