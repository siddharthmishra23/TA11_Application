from flask import Flask, jsonify
import pandas as pd
import os
import numpy as np
from faker import Faker  
from flask_cors import CORS, cross_origin
import schedule
import time
import threading

app = Flask(__name__)
CORS(app)

global footprint, user_df

def update_data():
    # 定义csv文件路径
    path = os.getcwd() + "/db"
    elec_path = os.path.join(path, "electricity.csv")
    gas_path = os.path.join(path, "gas.csv")
    suburb_path = os.path.join(path, "suburb.csv")

    # 读取csv文件
    elec_df = pd.read_csv(elec_path)
    gas_df = pd.read_csv(gas_path)
    suburb_df = pd.read_csv(suburb_path)

    # 使用year和postcode列将electricity和gas数据集合并
    df_gas_ele = pd.merge(elec_df, gas_df, how="inner", on=["year", "postcode"])

    # 使用postcode列将df_gas_ele与suburb数据集合并
    global footprint
    footprint = pd.merge(df_gas_ele, suburb_df, how="inner", on="postcode")

    # 创建 Faker 对象来生成随机姓名
    fake = Faker()

    # 创建 user DataFrame
    global user_df
    user_df = pd.DataFrame({
        "name": [fake.name() for _ in range(suburb_df.shape[0])],  
        "suburb": np.random.choice(suburb_df['suburb'], size=suburb_df.shape[0]),  
        "gas_emi_per_day": np.random.randint(1, 10, size=suburb_df.shape[0]),  
        "ele_emi_per_day": np.random.randint(1, 10, size=suburb_df.shape[0])  
    })

    # 添加新列 all_overhead，计算 gas_emi_per_day 和 ele_emi_per_day 的和
    user_df['all_overhead'] = user_df['gas_emi_per_day'] + user_df['ele_emi_per_day']

# 初始更新数据
update_data()

# 设定定时任务，每10分钟执行一次
schedule.every(10).minutes.do(update_data)

# 启动一个后台线程处理定时任务
def run_schedule():
    while True:
        schedule.run_pending()
        time.sleep(1)

threading.Thread(target=run_schedule).start()

#Api: http://localhost:5000/process
@app.route('/process', methods=['GET'])
def process_data():
    # 转换 DataFrame 为 JSON
    result_json = footprint.to_json(orient="records")

    return result_json

#Api: http://localhost:5000/generate_user
@app.route('/generate_user', methods=['GET'])  # 新增的路由
def generate_user():
    # 转换 DataFrame 为 JSON
    user_json = user_df.to_json(orient="records")

    return user_json

if __name__ == '__main__':
    app.run(debug=True)
