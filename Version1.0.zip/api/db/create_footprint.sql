CREATE SCHEMA footprint;

/*drop table footprint.electricity;
drop table footprint.gas;
drop table footprint.user;
drop table footprint.suburb;*/
CREATE TABLE footprint.user (
    username VARCHAR(50) PRIMARY KEY,
    gas_emi_per_day DECIMAL(5, 2),
    ele_emi_per_day DECIMAL(5, 2)
);
CREATE TABLE footprint.suburb (
    postcode INT PRIMARY KEY,
    suburb VARCHAR(100)
);
CREATE TABLE footprint.gas (
    year INT,
    postcode INT,
    total_gas_gj DECIMAL(10, 2),
    avg_intensity_per_customer_annum DECIMAL(10, 2),
    avg_intensity_per_customer_day DECIMAL(10, 2),
    total_CO2_kg DECIMAL(10, 2),
    avg_CO2_kg_per_customer_year DECIMAL(10, 2),
    avg_CO2_kg_per_customer_day DECIMAL(10, 2),
    PRIMARY KEY (year, postcode)
);

CREATE TABLE footprint.electricity (
    year INT,
    postcode INT,
    total_electricity_kwh DECIMAL(10, 2),
    avg_intensity_per_customer_annum DECIMAL(10, 2),
    avg_intensity_per_customer_day DECIMAL(10, 2),
    total_CO2_kg DECIMAL(10, 2),
    avg_CO2_kg_per_customer_year DECIMAL(10, 2),
    avg_CO2_kg_per_customer_day DECIMAL(10, 2),
    PRIMARY KEY (year, postcode)
);




